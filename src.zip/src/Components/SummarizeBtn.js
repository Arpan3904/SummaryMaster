import React from 'react';

const SummarizeBtn = ({ onClick }) => {
  return (
    <button onClick={onClick}>
      SUMMARIZE THIS
    </button>
  );
};

export default SummarizeBtn;