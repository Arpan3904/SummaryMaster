// RangeSlider.js
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Slider from '@mui/material/Slider';
import { setSliderValue } from './sliderReducer';

const RangeSlider = () => {
  const dispatch = useDispatch();
  const sliderValue = useSelector((state) => state.sliderValue);

  const handleSliderChange = (event, newValue) => {
    dispatch(setSliderValue(newValue));
  };

  return (
    <Slider
      value={sliderValue}
      onChange={handleSliderChange}
      aria-label="Default"
      valueLabelDisplay="auto"
    />
  );
};

export default RangeSlider;
