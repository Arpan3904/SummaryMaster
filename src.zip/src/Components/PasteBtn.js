import React from 'react';

function PasteBtn({setValue}){
    return(
        <button
        onClick={() => navigator.clipboard.readText().then((clipText) => setValue(clipText))}
        className="absolute top-1/2 right-2 transform -translate-y-1/2 bg-gray-300 text-gray-700 rounded-md text-sm p-2"
        >
        Paste
        </button>
    );
}
export default PasteBtn;

