import { Document, Packer, Paragraph, TextRun } from "docx";

const convertDocxToText = async (file) => {
  const reader = new FileReader();

  reader.onload = async (event) => {
    const buffer = event.target.result;
    const doc = await Document.load(buffer);
    const text = doc.getText();
    console.log(text);
  };

  reader.readAsArrayBuffer(file);
};

const DocxToText = () => {
  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (file) {
      await convertDocxToText(file);
    }
  };

  return (
    <div>
      <input type="file" onChange={handleFileChange} />
    </div>
  );
};

export default DocxToText;
