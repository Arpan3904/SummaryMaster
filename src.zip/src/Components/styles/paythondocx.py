from flask import Flask, request, jsonify
from docx import Document

app = Flask(__name__)

@app.route('/docx', methods=['POST'])
def process_docx():
    try:
        uploaded_file = request.files['file']
        if uploaded_file.filename != '':
            # Save the file temporarily
            temp_file_path = 'temp.docx'
            uploaded_file.save(temp_file_path)

            # Read the content of the file
            text_content = read_docx(temp_file_path)
            print(text_content )
            # Remove the temporary file
            import os
            os.remove(temp_file_path)

            return jsonify({'text_content': text_content})
    except Exception as e:
        print('Error:', e)
        return 'Error processing file', 500

def read_docx(file_path):
    doc = Document(file_path)
    text = []
    for paragraph in doc.paragraphs:
        text.append(paragraph.text)
    return '\n'.join(text)

if __name__ == '__main__':
    app.run(port=5011,debug=True)
