import { sendPasswordResetEmail } from "firebase/auth";
import React from "react";
import { auth } from './config';
import { useNavigate } from "react-router-dom";
import './styles/forgotpassword.css'

function ForgotPassword() {
    const navigate = useNavigate(); // Move useNavigate hook outside the handleSubmit function

    const handleSubmit = async (e) => {
        e.preventDefault();
        const emailVal = e.target.email.value;

        sendPasswordResetEmail(auth, emailVal)
            .then(() => {
                alert("Check your email");
                navigate("/"); // Use navigate directly
            })
            .catch((err) => {
                alert(err.code);
            });
    }

    return (
        <div className="App">
            <h1>Forgot Password</h1>
            <form onSubmit={(e) => handleSubmit(e)}>
                <input name="email" /><br/><br/>
                <button type="submit">Reset</button>
            </form>
        </div>
    )
}

export default ForgotPassword;
