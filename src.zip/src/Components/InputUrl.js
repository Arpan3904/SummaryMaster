import React, { useState, useEffect } from "react";
import axios from "axios";
import PasteBtn from "./PasteBtn";
import Summary from './Summary'
import './styles/InputUrl.css'
import RelatedVideos from "./RelatedVideo";




const InputUrl = () => {

  const [isSummaryVisible, setIsSummaryVisible] = useState(false);

  const [url, setUrl] = useState("");
  const [videoId, setVideoId] = useState("");
  const [videoInfo, setVideoInfo] = useState({});
  const [channelInfo, setChannelInfo] = useState({});
  
  const [summaryText, setSummaryText] = useState('');
  const handleDataFromSummary = (Visible, Summary) => {
    setIsSummaryVisible(Visible);
    setSummaryText(Summary);  
  };
  

  const extractVideoId = (url) => {
    const match = url.match(
      /^(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/
    );
    return match ? match[1] : null;
  };

  const fetchVideoInfo = async (videoId) => {
    try {
      const response = await axios.get(
        `https://www.googleapis.com/youtube/v3/videos?id=${videoId}&part=snippet&key=AIzaSyCZGkQI8NTYXA9wI5uhy0VC-qjRvsKH3WM `
      );

      if (response.data.items && response.data.items.length > 0) {
        setVideoInfo(response.data.items[0].snippet);
        // Fetch channel information using the channel ID
        fetchChannelInfo(response.data.items[0].snippet.channelId);
      }
    } catch (error) {
      console.error("Error fetching video information:", error.message);
    }
  };

  const fetchChannelInfo = async (channelId) => {
    try {
      const response = await axios.get(
        `https://www.googleapis.com/youtube/v3/channels?id=${channelId}&part=snippet&key=AIzaSyCZGkQI8NTYXA9wI5uhy0VC-qjRvsKH3WM`
      );
      console.log("Channel API Response:", response.data);

      if (response.data.items && response.data.items.length > 0) {
        setChannelInfo(response.data.items[0].snippet);
      }
    } catch (error) {
      console.error("Error fetching channel information:", error.message);
    }
  };

  const handleUrlChange = (e) => {
    const inputUrl = e.target.value;
    setUrl(inputUrl);
    const id = extractVideoId(inputUrl);
    setVideoId(id);

    if (id) {
      fetchVideoInfo(id);
    }
  };

  const handlePaste = (content) => {
    setUrl(content);
    const id = extractVideoId(content);
    setVideoId(id);

    if (id) {
      fetchVideoInfo(id);
    }
  };
  
  return (
    <div className="container" style={{width:'80vw'}}>
      <div className="input-section">
       
        <input
          type="text"
          placeholder="Enter YouTube URL"
          value={url}
          onChange={handleUrlChange}
          className="url-input"
        />
        <PasteBtn setValue={handlePaste} />
      </div>
      {videoId && (
        <>
          <div>
            <iframe
              width="100%"
              height="415"
              src={`https://www.youtube.com/embed/${videoId}`}
              title="YouTube video player"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
              className="video-iframe"
            ></iframe>

            
              <Summary contentType="url" content={url} onDataReceived={handleDataFromSummary}/>
      
              

          </div>
          {/* <RelatedVideos/> */}
          <div className="info-section">
            <h3>Video Information</h3>
            <p className="info-heading">Title: {videoInfo.title}</p>
            <p>Description: {videoInfo.description}</p>
          </div>
          <div className="info-section">
            <h3>Channel Information</h3>
            <p className="info-heading">Channel Name: {channelInfo.title}</p>
            <p>Channel Description: {channelInfo.description}</p>
          </div>
         
        </>
      )}
    </div>
  );
};

export default InputUrl;
