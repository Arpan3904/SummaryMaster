// Keywords.js
import React from "react";
import { keyset } from "./DataFetcherText";
import "./styles/Keywords.css"; // Import the CSS file

const Keywords = () => {
  if (!keyset) {
    // Handle the case where keyset is undefined
    return <></>;
  } 

  return (
    <div className="keywords-container">
      <h2 className="keywords-heading">Keywords:</h2>
      <div className="keywords-list">
        {Array.from(keyset).map((keyword, index) => (
          <div key={index} className="keyword-item">
            {keyword}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Keywords;
