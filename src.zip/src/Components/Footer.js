import React from 'react';
import logoImage from '../Components/images/logo.png'
import './styles/Footer.css'

const Footer = () => {
  return (
    
    <footer className="py-12 md:py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="grid md:grid-cols-12 gap-8 lg:gap-20 mb-8 md:mb-12">
          <div className="md:col-span-4 lg:col-span-5">
            <div className="mb-2">
              <a className="block" aria-label="TLDR This" href="/">
                <img
                  alt="TLDR This"
                  loading="lazy"
                  width="80"
                  height="30"
                  decoding="async"
                  src={logoImage}
                />
              </a>
            </div>
          </div>
          <div className="md:col-span-8 lg:col-span-7 grid sm:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-2">Company</h3>
              {/* Add Company-related content here */}
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">Developers</h3>
              {/* Add Developers-related content here */}
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">Quick Links</h3>
              {/* Add Quick Links or other relevant content here */}
            </div>
          </div>
        </div>
        <div className="md:flex md:items-center md:justify-between">
          <ul className="flex mb-4 md:order-1 md:ml-4 md:mb-0">
            {/* Add your social media links here */}
            <li className="mr-4">
              <a href="#" className="text-gray-500 hover:text-gray-700">
                <i className="fab fa-facebook"></i>
              </a>
            </li>
            <li className="mr-4">
              <a href="#" className="text-gray-500 hover:text-gray-700">
                <i className="fab fa-twitter"></i>
              </a>
            </li>
            {/* Add more social media links as needed */}
          </ul>
          <div className="text-gray-400 text-sm mr-4">© 2023 Summary Master, all rights reserved</div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
