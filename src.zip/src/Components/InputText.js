import React, { useState } from "react";
import PasteBtn from "./PasteBtn";
import Summary from "./Summary";
import SummarizeText from "./SummarizeText";
import RelatedVideos from "./RelatedVideo";

const InputText = () => {
  const [text, setText] = useState("");
  const [isSummaryVisible, setIsSummaryVisible] = useState(false);
  const [summaryText, setSummaryText] = useState('');
  

  const handleDataFromSummary = (isVisible, summary) => {
    setIsSummaryVisible(isVisible);
    setSummaryText(summary);
  };

  const handleTextChange = (e) => {
    setText(e.target.value);
  };

  const handleCopyText = () => {
    navigator.clipboard.writeText(text);
    // You can also provide some UI feedback here, like a toast message
    alert("Text copied to clipboard!");
  };

  return (
    <div style={{width:'80vw'}}>
      <center>
      <div style={{ display: 'flex' }}>
        <textarea
          name="text"
          id="text"
          maxLength="10000"
          placeholder="Enter your text here..."
          className="block w-full py-3 px-4 bg-transparent focus:ring-0 text-base focus:outline-none rounded-lg h-32 pr-10"
          required=""
          value={text}
          onChange={handleTextChange}
          rows={(text.length / 76) + 1}
          style={isSummaryVisible ? { height: '25vw', width: '85vw', marginTop: '23px' } : null}
        ></textarea>
      
        {/* <button onClick={handleCopyText} className="ml-2 p-2 bg-blue-500 text-white rounded-md">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-6 w-6"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2m-4 10v4m-3-3h4"
            />
          </svg>
          <span className="ml-1">Copy</span>
        </button> */}
      
        {isSummaryVisible && (
          <SummarizeText Text={summaryText} />
        )}
      </div>
      </center>
      <PasteBtn setValue={setText} />
      <Summary contentType="text" content={text} onDataReceived={handleDataFromSummary} />
      
      {isSummaryVisible&&<RelatedVideos/>}
    </div>
  );
};

export default InputText;
