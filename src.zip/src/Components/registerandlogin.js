import React, { useState } from "react";
import { auth } from './config';
import {toast} from 'react-toastify';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from "firebase/auth";
import { useNavigate } from "react-router-dom";
import './styles/registerandlogin.css';
import GoogleSignIn from './googlesignin'
function RegisterAndLogin() {
  const [login, setLogin] = useState(true); // Set to true to make Sign In active by default

  const history = useNavigate();
  const navigate = useNavigate();

  const handleSubmit = (e, type) => {
    e.preventDefault();
    const email = e.target.email.value;
    const password = e.target.password.value;

    if (type === "signup") {
      createUserWithEmailAndPassword(auth, email, password)
        .then((data) => {
          console.log(data, "authData");
          // Change the tab to SignIn
          toast.success("successfully getted")
          setLogin(true);
        })
        .catch((err) => {
          toast(err.code);
          setLogin(true);
        });
    } else {
      signInWithEmailAndPassword(auth, email, password)
        .then((data) => {
          console.log(data, "authData");
          navigate('./home');
        })
        .catch((err) => {
          toast.error(err.code);
        });
    }
  };

  const handleReset = () => {
    navigate("/reset");
  };

  return (
    <div className="App">
      {/* Registration and login Screen */}
      <div className="row">
        <div
          className={!login ? "activeColor" : "pointer"}
          onClick={() => setLogin(false)}
        >
          SignUp
        </div>
        <div
          className={login ? "activeColor" : "pointer"}
          onClick={() => setLogin(true)}
        >
          SignIn
        </div>
      </div>
      <h1>{login ? "SignIn" : "SignUp"}</h1>
      <form onSubmit={(e) => handleSubmit(e, login ? "signin" : "signup")}>
        <input name="email" placeholder="Email" />
        <br />
        <input name="password" type="text" placeholder="Password" />
        <br />
        <a onClick={handleReset}>Forgot Password?</a>
        <br />
        <button>{login ? "SignIn" : "SignUp"}</button>
      </form>
      <div className="googlesignin">
        <br />
      <GoogleSignIn />
      </div>
    </div>
    
  );
}

export default RegisterAndLogin;
