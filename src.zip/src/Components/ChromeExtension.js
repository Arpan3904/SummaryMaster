import React from 'react';
import './styles/ChromeExtension.css';

const ChromeExtension = () => {
  return (
    <div className="chrome-extension-container">
      <h2>Get Our Chrome Extension</h2>
      <p>
        Enhance your browsing experience with our Chrome extension. Stay up-to-date and enjoy additional features!
      </p>
      <div className="installation-guide">
        <h3>Installation Guide</h3>
        <ol>
          <li>Visit the Chrome Web Store.</li>
          <li>Search for "Your Extension Name".</li>
          <li>Click on "Add to Chrome" and follow the on-screen instructions.</li>
        </ol>
      </div>
      <div className="chrome-store-link">
        <a href="https://chrome.google.com/webstore" target="_blank" rel="noopener noreferrer">
          <img
            src="chrome-store-badge.png"
            alt="Chrome Web Store"
            width="200"
            height="60"
          />
        </a>
      </div>
    </div>
  );
};

export default ChromeExtension;
