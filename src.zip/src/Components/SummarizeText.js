import React, { useState, useEffect } from "react";

const SummarizeText = ({ Text ,contentType}) => {
  const [text, setText] = useState("");
 

  useEffect(() => {
    setText(Text);
  }, [Text]);

  return (
    <textarea
      name="summarizeText"
      id="summarizeText"
      placeholder="First Enter Text Above than Click On Summarize"
      className="block w-full py-3 px-4 bg-transparent focus:ring-0 text-base focus:outline-none rounded-lg h-32 mt-4"
      required=""
      value={text}
      readOnly={true}
      rows={(text.length/76) + 1}
      style={!contentType==='url' ?{ height:'25vw' , width:'50%'}:{height:'25vw' }}
    ></textarea>
  );
};

export default SummarizeText;
