import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { keyset } from "./DataFetcherText";
import './styles/RelatedVideo.css'; // Import your CSS file

const RelatedVideos = () => {
  const [videos, setVideos] = useState([]);

  const handleSearch = async () => {
    // Extract keywords or topics from the input paragraph
    const keywords = keyset // You need to implement this function
    console.log(keywords);
    try {
      // Search for related videos using the extracted keywords
      const response = await axios.get('https://www.googleapis.com/youtube/v3/search', {
        params: {
          part: 'snippet',
          q: keywords.join(' '), // Concatenate keywords into a search query
          type: 'video',
          key: 'AIzaSyCZGkQI8NTYXA9wI5uhy0VC-qjRvsKH3WM',
        },
      });
      
      setVideos(response.data.items);
    } catch (error) {
      console.error('Error fetching related videos:', error);
    }
  };
  useEffect(() => {
    handleSearch(); // Call handleSearch when component mounts
  }, []);
  return (
    <div>
        
      <h2>Related Videos</h2>
      <div className="related-videos-container">
        {videos.map((video) => (
          <div className="related-video" key={video.id.videoId}>
            <iframe
              width="100%"
              height="100%"
              src={`https://www.youtube.com/embed/${video.id.videoId}`}
              title={video.snippet.title}
              frameBorder="0"
              allowFullScreen   
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default RelatedVideos;
