from transformers import pipeline
from youtube_transcript_api import YouTubeTranscriptApi
from flask import Flask, jsonify, request

app = Flask(__name__)

@app.route('/arpann', methods=['POST'])
def example_endpoint():
    data = request.get_json()
    
    print(data.url)
    
    response_data = {"message": "Request received successfully"}
    return jsonify(response_data)

if __name__ == '__main__':
    app.run(debug=True, port=8000)


