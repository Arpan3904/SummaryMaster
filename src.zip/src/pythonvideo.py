import moviepy.editor as mp 
import speech_recognition as sr 

# Load the video 
video = mp.VideoFileClip(r"C:\\Users\\arpan\\OneDrive\\Desktop\\proj123\\summary-master\\src\\video1.mp4") 

# Extract the audio from the video 
audio_file = video.audio 
audio_file.write_audiofile("geeksforgeeks.wav") 

# Initialize recognizer 
r = sr.Recognizer() 

# Load the audio file 
with sr.AudioFile("geeksforgeeks.wav") as source: 
    data = r.record(source) 

try:
    # Convert speech to text 
    text = r.recognize_google(data) 

    # Print the text 
    print("\nThe resultant text from video is: \n") 
    print(text) 
except sr.UnknownValueError:
    print("Google Speech Recognition could not understand the audio.")
except sr.RequestError as e:
    print("Could not request results from Google Speech Recognition service; {0}".format(e))
