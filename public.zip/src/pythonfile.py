from flask import Flask, jsonify, request
from flask_cors import CORS
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from nltk.probability import FreqDist

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

def preprocess_text(text):
    sentences = sent_tokenize(text)
    words = word_tokenize(text)
    stop_words = set(stopwords.words('english'))
    words = [word.lower() for word in words if word.isalnum() and word.lower() not in stop_words]
    return sentences, words

def calculate_word_frequencies(words):
    word_frequencies = FreqDist(words)
    return word_frequencies

def calculate_sentence_scores(sentences, word_frequencies):
    sentence_scores = {}

    for i, sentence in enumerate(sentences):
        for word, freq in word_frequencies.items():
            if word in sentence.lower():
                if i not in sentence_scores:
                    sentence_scores[i] = freq
                else:
                    sentence_scores[i] += freq

    return sentence_scores

@app.route('/summary', methods=['POST'])
def generate_summary():
    if 'text' in request.form:
        text = request.form['text']
    elif 'file' in request.files:
        file = request.files['file']
        text = file.read().decode('utf-8')
    else:
        return jsonify({'error': 'No text or file provided'})

    summary_percentage = float(request.form['sliderValue'])  # Convert to float

    sentences, words = preprocess_text(text)
    word_frequencies = calculate_word_frequencies(words)
    sentence_scores = calculate_sentence_scores(sentences, word_frequencies)

    total_sentences = len(sentences)
    num_sentences = int(total_sentences * (summary_percentage / 100))

    sorted_sentences = sorted(sentence_scores.items(), key=lambda x: x[1], reverse=True)
    summary_sentences = [sentences[i] for i, _ in sorted_sentences[:num_sentences]]
    summary = ' '.join(summary_sentences)
    
    return jsonify({'summary': summary})

if __name__ == "__main__":
    app.run(debug=True, port=8002)
