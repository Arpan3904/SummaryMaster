import speech_recognition as sr
import pyttsx3 
from pydub import AudioSegment

# Initialize the recognizer 
r = sr.Recognizer() 

# Function to convert text to speech
def SpeakText(command):
    # Initialize the engine
    engine = pyttsx3.init()
    engine.say(command) 
    engine.runAndWait()

# Function to generate summary from text (you can replace this with your own summary generation code)
def generate_summary(text):
    # Your summary generation logic here
    # For example, you can use NLP techniques, extract key phrases, or use summarization libraries
    
    # For demonstration purposes, let's just return the first 50 characters as summary
    return text[:50]

# Function to transcribe audio from MP3 file
def transcribe_mp3(mp3_file):
    # Load the MP3 file
    audio = AudioSegment.from_mp3(mp3_file)
    audio.export("temp.wav", format="wav")  # Convert MP3 to WAV
    
    # Transcribe the WAV file
    with sr.AudioFile("temp.wav") as source:
        audio_data = r.record(source)
        text = r.recognize_google(audio_data)
        return text

# Replace "your_mp3_file.mp3" with the path to your MP3 file
mp3_file = "C:/Users/arpan/OneDrive/Desktop/proj123/summary-master/src/2.mp3"

try:
    # Transcribe the MP3 file
    transcribed_text = transcribe_mp3(mp3_file)
    print("Transcribed text:", transcribed_text)

    # Generate summary from transcribed text
    summary = generate_summary(transcribed_text)
    print("Summary:", summary)
    
    # Speak the summary
    SpeakText(summary)
    
except sr.RequestError as e:
    print("Could not request results; {0}".format(e))
    
except sr.UnknownValueError:
    print("Unknown error occurred")
