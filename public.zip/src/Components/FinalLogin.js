    import React, { useState, useEffect } from 'react';
    import '../Components/styles/styles.css'; // Assuming you have a CSS file for 
    import { auth } from './config';
    import {toast} from 'react-toastify';
    import {
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    } from "firebase/auth";
    import { useNavigate } from "react-router-dom";
    import GoogleSignIn from './googlesignin'

    const DoubleSliderSignInUpForm = () => {
        const [login, setLogin] = useState(true); // Set to true to make Sign In active by default

        const history = useNavigate();
        const navigate = useNavigate();

        const handleSubmit = (e, type) => {
            e.preventDefault();
            const email = e.target.email.value;
            const password = e.target.password.value;
        
            if (type === "signup") {
            createUserWithEmailAndPassword(auth, email, password)
                .then((data) => {
                console.log(data, "authData");
                // Change the tab to SignIn
                toast.success("successfully getted")
                setLogin(true);
                })
                .catch((err) => {
                toast(err.code);
                setLogin(true);
                });
            } else {
            signInWithEmailAndPassword(auth, email, password)
                .then((data) => {
                console.log(data, "authData");
                navigate('./home');
                })
                .catch((err) => {
                toast.error(err.code);
                });
            }
        };

        const handleReset = () => {
            navigate("/reset");
        };
    const handleSignUpClick = () => {
        const container = document.getElementById('container');
        container.classList.add("right-panel-active");
    };

    const handleSignInClick = () => {
        const container = document.getElementById('container');
        container.classList.remove("right-panel-active");
    };

    return (
        <div className="container" id="container">
        <div className="form-container sign-up-container">
            <form onSubmit={(e) => handleSubmit(e, "signup")}>
            <h1>Create Account</h1>
            <div className="social-container">
                {/* <a href="#" className="social"><i className="fab fa-facebook-f"></i></a> */}
                <a href="#" className="social"><i className="fab fa-google-plus-g"></i></a>
                {/* <a href="#" className="social"><i className="fab fa-linkedin-in"></i></a> */}
            </div>
            <span>or use your email for registration</span>
            <input name="email" placeholder="Email" />
            <input name="password" type="text" placeholder="Password" />
            <button>Sign Up</button>
            </form>
        </div>
        <div className="form-container sign-in-container">
            <form onSubmit={(e) => handleSubmit(e, "SignIn")}>
            <h1>Sign in</h1>
            <div className="social-container">
                {/* <a href="#" className="social"><i className="fab fa-facebook-f"></i></a> */}
                <a href="#" className="social"><i className="fab fa-google-plus-g"></i></a>
                {/* <a href="#" className="social"><i className="fab fa-linkedin-in"></i></a> */}
            </div>
            <span>or use your account</span>
            <input name="email" placeholder="Email" />
            <input name="password" type="text" placeholder="Password" />
            <a onClick={handleReset}>Forgot Password?</a>
            <button >Sign In</button>
            </form>
        </div>
        <div className="overlay-container">
            <div className="overlay">
            <div className="overlay-panel overlay-left">
                <h1>Welcome Back!</h1>
                <p>To keep connected with us please login with your personal info</p>
                <button className="ghost" onClick={handleSignInClick}>Sign In</button>
            </div>
            <div className="overlay-panel overlay-right">
                <h1>Hello, Friend!</h1>
                <p>Enter your personal details and start journey with us</p>
                <button className="ghost" onClick={handleSignUpClick}>Sign Up</button>
            </div>
            </div>
        </div>
        </div>
    );
    };

    export default DoubleSliderSignInUpForm;
