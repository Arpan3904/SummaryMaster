// FileSection.js
import React from "react";
import InputFile from "./InputFile";

const FileSection = () => {
  return (
    <>
      <div className="relative">
        <InputFile />
      </div>
     
    </>

  );
};

export default FileSection;
