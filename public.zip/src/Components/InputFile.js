import React, { useState } from "react";
import Summary from "./Summary";


const InputFile = () => {
  const [file, setFile] = useState("");
  const [text, setText] = useState("");
  const [isSummaryVisible, setIsSummaryVisible] = useState(false);
  const [isFileText, setIsFileText] = useState(false);
  const handleDataFromSummary = (isVisible, summary) => {
    // setIsSummaryVisible(isVisible);
    // setSummaryText(summary);
  };

  const handleTextChange = (e) => {
    setText(file);
  };

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    setFile(file);

    if (file) {
      const fileExtension = file.name.split(".").pop().toLowerCase();
      if (fileExtension === "txt") {
        const reader = new FileReader();

        reader.onload = (event) => {
          const content = event.target.result;
          setText(content);
         
        };

        reader.readAsText(file);
        setIsFileText(true);
      } else if (fileExtension === "docx") {
        const formData = new FormData();
        formData.append("file", file);

        try {
          const response = await fetch("http://localhost:5011/docx", {
            method: "POST",
            body: formData,
          });

          if (response.ok) {
            const textContent = await response.json();
            console.log(textContent.text_content);
            setText(textContent.text_content);
            setIsFileText(true);  
            
          } else {
            console.error("Error processing file");
          }
        } catch (error) {
          console.error("Error:", error);
        }
       
      } else {
        console.error("Unsupported file format");
      }
    }
  };

  return (
    <>
      <input type="file" onChange={handleFileChange} />
      {isFileText && (
        <textarea
          name="text"
          id="text"
          maxLength="10000"
          placeholder="Enter your text here..."
          className="block w-full py-3 px-4 bg-transparent focus:ring-0 text-base focus:outline-none rounded-lg h-32 pr-10"
          required=""
          value={text}
          onChange={handleTextChange}
          rows={file.length / 76 + 1}
          style={{ height: "auto" }}
        ></textarea>)}
      
     {isFileText && <Summary contentType="file" content={text} onDataReceived={handleDataFromSummary}/>}
    </>
  );
};

export default InputFile;
