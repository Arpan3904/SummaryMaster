// Keywords.js
import React from "react";
import { keyset } from "./DataFetcherText";


const Keywords = () => {
  if (!keyset) {
    // Handle the case where keyset is undefined
    return <></>;
  } 

  return (
    <div className="keywords-container" style={{backgroundColor:"rgb(51, 54, 58)",width:"60vw",marginLeft:'39vh',marginTop:"10vh",borderRadius:"6px"}}>
      <center><h2 className="keywords-heading" style={{color:"white",marginTop:"25px"}}>Keywords:</h2></center>
      <center>
      <div className="keywords-list" style={{display:"flex"}}>
        {Array.from(keyset).map((keyword, index) => (
          <div key={index} className="keyword-item" style={{color:"white",margin:"7vh"}}>
            {keyword}
          </div>
        ))}
      </div>
      </center>
    </div>
  );
};

export default Keywords;
