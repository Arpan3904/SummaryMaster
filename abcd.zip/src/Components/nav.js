import React, { useEffect, useState } from 'react';
//import 'bootstrap/dist/css/bootstrap.min.css';
//import { Navbar, Nav, Container, Button } from 'react-bootstrap';
import { Brightness4, Brightness7 } from '@mui/icons-material'; // Import icons
import './styles/myStyles.css'
import { useNavigate } from 'react-router-dom'; 
// import Logo from './images/logo.png';
import logo from './images/logo.png';
import { onAuthStateChanged, getAuth, signOut } from 'firebase/auth';


function CustomNavbar() {
  const [user, setUser] = useState(null);
  const [darkMode, setDarkMode] = useState(false);
  const navigate = useNavigate();
  const auth = getAuth();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      
    });

    // Cleanup subscription on unmount
    return () => unsubscribe();
  }, [auth]);

  const handleLoginClick = () => {
    if (user) {
      // If user is logged in, sign out
      signOut(auth);
    } else {
      // If user is not logged in, navigate to login page
      navigate('/login');
    }
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  return (
    <>
      {/* <Navbar expand="lg" className={`custom-navbar ${darkMode ? 'dark' : 'light'}`}>
        <Container>
          <Navbar.Brand href="#">
            <img
              src={Logo}
              alt="Logo"
              className="img-fluid logo-img"
            />
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="navbarNavDropdown" />
          <Navbar.Collapse id="navbarNavDropdown">
            <Nav className="me-auto"> */}
              {/* Add your navigation links here */}
            {/* </Nav>
            <div className="d-flex align-items-center">
              <Button variant="light" className="ms-3" onClick={toggleDarkMode}>
                {darkMode ? <Brightness7 /> : <Brightness4 />}
              </Button>
              <Button variant="light" className="ms-3" onClick={handleLoginClick}>
      
                {user ? user.email : 'Login'}
              </Button>
            </div>
          </Navbar.Collapse>
        </Container>
      </Navbar> */}
      <div className='header-container'>
      <img src={logo} alt='logo' />
      <div className='header-middle'>
        <ui>
          <li><a href=''>SummarizeNow</a></li>
          <li><a href=''>Browser Extensions</a></li>
          <li><a href=''>Features</a></li>
          {/* <li><a href=''>Pricing</a></li> */}
          {/* <li><a href=''>Products</a></li> */}
        </ui>
      </div>
      <div className='header-last'>
        {/* <button className='last-btn1'>Sign In</button> */}
              <button variant="light" className="last-btn2" onClick={handleLoginClick}>
      
                {user ? user.email : 'Sign In'}
              </button>
        {/* <button className='last-btn2'>Sign Up</button> */}
      </div>
    </div>
    </>
  );
}

export default CustomNavbar;

