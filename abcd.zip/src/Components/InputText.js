import React, { useState } from "react";
import PasteBtn from "./PasteBtn";
import Summary from "./Summary";
import SummarizeText from "./SummarizeText";
import RelatedVideos from "./RelatedVideo";
import RangeSlider from "./RangeSlider";

const InputText = () => {
  const [text, setText] = useState("");
  const [isSummaryVisible, setIsSummaryVisible] = useState(false);
  const [summaryText, setSummaryText] = useState("");

  const handleDataFromSummary = (isVisible, summary) => {
    setIsSummaryVisible(isVisible);
    setSummaryText(summary);
  };

  const handleTextChange = (e) => {
    setText(e.target.value);
  };

  const handleCopyText = () => {
    navigator.clipboard.writeText(text);
    // You can also provide some UI feedback here, like a toast message
    alert("Text copied to clipboard!");
  };

  return (
    // <div style={{width:'80vw'}}>
    //   <center>
    //   <div style={{ display: 'flex' }}>
    //     <textarea
    //       name="text"
    //       id="text"
    //       maxLength="10000"
    //       placeholder="Enter your text here..."
    //       className="block w-full py-3 px-4 bg-transparent focus:ring-0 text-base focus:outline-none rounded-lg h-32 pr-10"
    //       required=""
    //       value={text}
    //       onChange={handleTextChange}
    //       rows={(text.length / 76) + 1}
    //       style={isSummaryVisible ? { height: '25vw', width: '85vw', marginTop: '23px' } : null}
    //     ></textarea>

    //     {isSummaryVisible && (
    //       <SummarizeText Text={summaryText} />
    //     )}
    //   </div>
    //   </center>
    //   <PasteBtn setValue={setText} />
    //   <Summary contentType="text" content={text} onDataReceived={handleDataFromSummary} />

    //   {isSummaryVisible&&<RelatedVideos/>}
    // </div>
    // <div className={isSummaryVisible ? "text-container1" : "text-container"}>
    // <div className={isSummaryVisible ? "container1" : "input-container"}>
    <>
    <center><RangeSlider /></center>
      <div style={{display:"flex"}}>
        <div
          style={
            isSummaryVisible
              ? {
                  height: "60vh",
                  width: "40vw",
                  backgroundColor: "white",
                  marginRight: "5px",
                  resize: "none",
                  marginLeft: "10vw",
                  borderRadius: "6px",
                }
              : {
                  resize: "none",
                  marginLeft: "25vw",
                  width: "50vw",
                  height: "60vh",
                  backgroundColor: "white",
                  borderRadius: "6px",
                }
          }
        >
          <div className="paste-button">
            <PasteBtn setValue={setText} />
          </div>

          <textarea
            value={text}
            onChange={handleTextChange}
            className="inputfield"
            style={
              isSummaryVisible
                ? {
                    width: "39vw",
                    height: "48vh",
                    border: "none",
                    fontSize: "large",
                  }
                : {
                    width: "49vw",
                    height: "48vh",
                    outline: "none",
                    border: "none",
                    fontSize: "large",
                  }
            }
            placeholder="Enter text Or Paste"
          />
        </div>

        {isSummaryVisible && <SummarizeText Text={summaryText} />}
      </div>
      {/* </div> */}
      <Summary
        contentType="text"
        content={text}
        onDataReceived={handleDataFromSummary}
      />

      {isSummaryVisible && <RelatedVideos />}
      {/* </div> */}
    </>
  );
};

export default InputText;
