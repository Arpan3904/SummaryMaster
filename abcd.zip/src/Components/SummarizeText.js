import React, { useState, useEffect } from "react";
import copy from "./images/copy.png"

const SummarizeText = ({ Text ,contentType}) => {
  const [text, setText] = useState("");
 

  useEffect(() => {
    setText(Text);
  }, [Text]);

  return (
    <div style={{display:"flex",flexDirection:"column",height:'60vh',resize:"none",width:'40vw',borderRadius:"6px",backgroundColor:"white"}}>
      <button style={{backgroundColor:"rgb(51,54,58)",border:"none",borderRadius:"6px"}}><img src={copy} style={{width:"2vw",height:"4vh"}}></img></button>
      <textarea
      name="summarizeText"
      id="summarizeText"
      placeholder="First Enter Text Above than Click On Summarize"
      className="block w-full py-3 px-4 bg-transparent focus:ring-0 text-base focus:outline-none rounded-lg h-32 mt-4"
      required=""
      value={text}
      readOnly={true}
      rows={(text.length/76) + 1}
      style={!contentType==='url' ?{ height:'25vw' , width:'50%',resize:"none"}:{height:'58vh',resize:"none",borderRadius:'6px',width:'39.5vw',backgroundColor:"white",border:"none"}}
    ></textarea>
    </div>
  );
};

export default SummarizeText;
