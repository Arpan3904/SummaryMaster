import React, { useState } from "react";

import InputText from "./InputText";

const TextSection = () => {
  return (
    <>
      <div className="relative">
        <InputText />
        
      </div>
     
    </>
  );
};

export default TextSection;


