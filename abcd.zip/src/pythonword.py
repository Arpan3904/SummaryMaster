from docx import Document

def read_docx(file_path):
    doc = Document(file_path)
    text = []
    for paragraph in doc.paragraphs:
        text.append(paragraph.text)
    return '\n'.join(text)

# Example usage:
file_path = 'src\\abcd.docx'
text_content = read_docx(file_path)
print(text_content)
